import java.util.Random;
///// ruth
public class TeachingAssistant implements Runnable {
	
	private Queue<Test> myTeachingAssistantQueue;
	private Queue<Test> secondTAQueue;
	private Queue<Test> lecturerQueue;
	private static boolean[] answers;
	private double p_error;
	private int salaryPerSecond = 3;
	private double totalSalary = 0;
	
	public TeachingAssistant(double p_error) {
		this.p_error = p_error;
	}

	@Override
	public void run() {
		while (true) { // TODO there is not massage from the lecturer
			Test t;
		  	try {
		  		t = myTeachingAssistantQueue.extract();
		  		int status = t.status;
		  		
//		  		Random rnd = new Random(); TODO
//	  			long workMiliSeconds = rnd.nextInt(1500,2500);
//	  			totalSalary = totalSalary + (workMiliSeconds/1000)*salaryPerSecond;
//	  			Thread.sleep(workMiliSeconds);
	  			
		  		if (status == 1) {
		  			// check the test with (p)
		  			t.status = 2;
		  			secondTAQueue.insert(t);
		  		} else {
		  			// check the test with (p/2)
		  			t.status = 3;
		  			lecturerQueue.insert(t);
		  		}
		  	} catch (InterruptedException e) {}
		}	
	}
	
//	private boolean[] randomAnswers() { // shuld go to the main
//		// TODO Auto-generated method stub
//		return null;
//	}

}
