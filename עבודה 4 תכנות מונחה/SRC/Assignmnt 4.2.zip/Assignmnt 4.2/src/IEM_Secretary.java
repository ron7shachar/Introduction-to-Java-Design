
public class IEM_Secretary implements Runnable {
	
	public static Queue<Test> iemSecretaryQueue = new Queue<Test>(); ;
	String name ;
	boolean only70plas ;
	public IEM_Secretary(String name1 , boolean only70plas ) {
	this.name = name ;	
	this.only70plas = only70plas;
	}
	
	@Override
	public void run() {
		while (true) { // TODO there are no more tests
			while(iemSecretaryQueue.isEmpty()) {
				try {
					iemSecretaryQueue.wait();
				} catch (InterruptedException e) {}	

			}
			try {
				f(iemSecretaryQueue.extract());
			} catch (InterruptedException e) {}
				}
			}

	private synchronized void f(Test test) {
		if (only70plas) {
			if(test.scoreAfterFactor>70) {
				dataEntry(test);
			}else {try {
				iemSecretaryQueue.insert(test);
				iemSecretaryQueue.notifyAll();
			} catch (InterruptedException e) {}}
		}else {
			if(test.scoreAfterFactor<=70) {
				dataEntry(test);
			}else {try {
				iemSecretaryQueue.insert(test);
				iemSecretaryQueue.notifyAll();
			} catch (InterruptedException e) {}
			
			}}
	}

	private void dataEntry(Test test) {
		// TODO Auto-generated method stub
		boolean full = false ;
		try {
			full = !EDW.EDW_Queue.insert(test);
		} catch (InterruptedException e) {}
		if(full) {
			try {
				EDW.EDW_Queue.wait();
			} catch (InterruptedException e) {}
			
		}
	}	
}


