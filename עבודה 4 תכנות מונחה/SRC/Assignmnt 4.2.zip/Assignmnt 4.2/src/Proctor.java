import java.util.Random;
///// ruth
public class Proctor implements Runnable {

	private String name;
	private int age;
	private int nStudents;
	
	private Queue<Student> proctorQueue;
	private Queue<Test> firstTAQueue;
	private Queue<Test> secondTAQueue;
	
	public Proctor( int nStudents) {
		this.proctorQueue = proctorQueue;
		this.nStudents = nStudents;
	}
	
	@Override
	public void run() {
		while (true) { // TODO all students didnt finish
			Student s;
		  	try {
		  		s = proctorQueue.extract();
		  		Test t;
		  		try {
		  			t = s.studentTest.extract();
		  			int classNumber = s.getClassNumber();
		  			// ����� �� �������
//		  			Random rnd = new Random(); TODO
//		  			long number = rnd.nextLong(1,3);
//		  			Thread.sleep(number*1000);
		  			if (firstTAQueue.size() <= secondTAQueue.size()) {
		  				firstTAQueue.insert(t);
		  			} else {
		  				secondTAQueue.insert(t);
		  			}
		  		} catch (InterruptedException e) {}
		  	} catch (InterruptedException e) {}	  				
		}
	}
	
}
