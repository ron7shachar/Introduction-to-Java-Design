
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


class GUI extends JFrame implements ActionListener {
	private JButton start;
	private JButton exit;
	private JComboBox<Object> numberOfEDR;
	private JComboBox<Object> p_error;
	private JLabel cost;
	private Object P_errorIngut;
	private Object numberEDR_inpot;
	//id,Name,TestRoom,QuestionAnswerTime,ProbabilityCorrect,HW_1,HW_2,HW_3,HW_4
	private Vector<String[]> inportVector = new  Vector<String[]>(); 
	private String sors = "input.txt"; 
	private Vector<Thread> vectorThraed ; 
	/////Queues
	
	
	public static void main(String[] args) throws IOException {
		new GUI();
		
	}
	public GUI() throws IOException {
		new JFrame("Chat Frame");
		makeEDR_menu();
		makePerror_menu();
		makeStartButton();
		makeExitButton();
		makeText();
		makeThePanel();
		
	imports(sors); 
	
		
	}
	
	
	private void start(double P_error, int numberOfEDR) {
		reset(P_error, numberOfEDR);
		for(Thread c : vectorThraed ) {
			c.start();
		}
		
		
	
	}
	// 	TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO	
		
		private void reset(double P_error, int numberOfEDR) {
			vectorThraed = new Vector<Thread>();
			// EDW	
			for(int i = 0;i < numberOfEDR; i++) {vectorThraed.add(new Thread(new EDW(inportVector.size())));}
			//IEM_Secretary
			vectorThraed.add(new Thread(new IEM_Secretary("Saron" ,  true )));
			vectorThraed.add(new Thread(new IEM_Secretary("Anat" ,  false )));
			//ExerciseChecker
			TreeMap<Integer, double[]> gradeList = new TreeMap<Integer, double[]>() ;
			double[] gradeListArr = new double[4];
			for(String[] arr : inportVector) {
				for(int i = 5;i<arr.length;i++) {
				gradeListArr[i-5] = Double.parseDouble(arr[i]);

				}
				gradeList.put(Integer.parseInt(arr[0]), gradeListArr);
			}
			vectorThraed.add(new Thread(new ExerciseChecker(gradeList)));
			//Lecturer
			vectorThraed.add(new Thread(new Lecturer("Coby")));
			//TeachingAssistant
			vectorThraed.add(new Thread( new TeachingAssistant(P_error)));
			vectorThraed.add(new Thread( new TeachingAssistant(P_error)));
			//Proctor
			vectorThraed.add(new Thread(new Proctor(inportVector.size() )));
			vectorThraed.add(new Thread(new Proctor(inportVector.size() )));
			vectorThraed.add(new Thread(new Proctor(inportVector.size() )));
			//Student 
			
			for(String[] arr : inportVector) {	
				vectorThraed.add(new Thread(new Student(Integer.parseInt(arr[0]), arr[1] + arr[2] ,Integer.parseInt(arr[3]), Double.parseDouble(arr[4]), Double.parseDouble(arr[4]))));
			}
			
			for(String[] arr : inportVector) {
				for(int i =0;i<arr.length;i++) {
				System.out.print(arr[i]);
				System.out.print(" ");
				}
				System.out.println();
			}
			
	}
	public void finished() { // TODO
		int cost = 0 ;
			//
		this.cost.setText("Total Cost : " + cost);
	
	}
	
// 	TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO	
	
	private void exit() {
		numberOfEDR.setSelectedIndex(0);
		p_error.setSelectedIndex(0);
		
	}
	


	private void makeThePanel() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setBounds(500, 200, 600, 300);
		this.setVisible(true);
		this.add(start);
		this.add(exit);
		this.add(numberOfEDR);
		this.add(p_error);
		this.add(cost);

	}

	private void makeExitButton() {
		exit = new JButton("EXIT");
		exit.setBounds(50, 50, 100, 50);
		exit.addActionListener(this);
		exit.setBackground(new Color(225, 40, 0));
	}

	private void makeStartButton() {
		start = new JButton("START");
		start.setBounds(250, 50, 100, 50);
		start.addActionListener(this);
		start.setBackground(new Color(0, 255, 0));

	}

	private void makePerror_menu() {
		Object[] P_error = new Object[72];
		P_error[0] = "p error :";
		int j = 1;
		for (double i = 20; i <= 90; i++) {
			P_error[j] = i / 100;
			j++;
		}
		p_error = new JComboBox<Object>(P_error);
		p_error.setBounds(50, 150, 120, 30);
		p_error.addActionListener(this);
		p_error.setEditable(false);

	}

	private void makeEDR_menu() {

		Object[] EDR = { "number of EDR :", 1, 2, 3 };
		numberOfEDR = new JComboBox<Object>(EDR);
		numberOfEDR.setBounds(250, 150, 120, 30);
		numberOfEDR.addActionListener(this);
		numberOfEDR.setEditable(false);

	}

	private void makeText() {
		cost = new JLabel("");
		cost.setBounds(400, 50, 100, 50);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == start) {

			if (!(P_errorIngut instanceof Double)) {
				P_errorIngut = 0.2;
			}
			if (!(numberEDR_inpot instanceof Integer)) {
				numberEDR_inpot = 2;
			}
			start(((double) (P_errorIngut)), ((int) (numberEDR_inpot)));

		}
		if (e.getSource() == exit) {
			exit();
		}
		if (e.getSource() == p_error) {
			P_errorIngut = p_error.getSelectedItem();
		}
		if (e.getSource() == numberOfEDR) {
			numberEDR_inpot = numberOfEDR.getSelectedItem();
		}

	}
	// 	TODO TODO TODO TODO TODO TODO TODO TODO TODO TODO
	
	public void imports(String import_questions) throws IOException { // import questions file and Update the questions
		BufferedReader inFile = null;
		try { // try to read the file
			FileReader fr = new FileReader(import_questions);
			inFile = new BufferedReader(fr);
		}
		catch (FileNotFoundException exception) { // if the file not found
			System.out.println("The file " + import_questions + " was not found.");
		} catch (IOException exception) {
		}
		String inputString = inFile.readLine(); 
		while (inputString != null) {
			inputString = inFile.readLine(); // reading the lines in the file
			if (inputString != null) {
				this.inportVector.add(inputString.split("	"));
			}
		}
		inFile.close();
	}

}

