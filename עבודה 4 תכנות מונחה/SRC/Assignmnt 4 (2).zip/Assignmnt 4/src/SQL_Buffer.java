
public class SQL_Buffer {

}
