
public class Student implements Runnable {
	private int id ;
	private String name ;
	private int classNumber;
	private double level ;
	public Student( int id,String name ,int classNumber,double level ) {
		this.id=id ;
		this.name = name;
		this.classNumber =classNumber ;
		this.level = level;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
