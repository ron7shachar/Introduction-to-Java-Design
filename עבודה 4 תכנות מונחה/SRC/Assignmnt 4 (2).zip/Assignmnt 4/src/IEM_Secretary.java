
public class IEM_Secretary implements Runnable {
	private Queue<Test> iemSecretaryQueue;
	
	
	
	public IEM_Secretary() {
		this.iemSecretaryQueue = new Queue<Test>(); 
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
