import java.util.TreeMap;

public class ExerciseChecker implements Runnable {

	private Queue<Test> teachingAssistantQueue;
	private TreeMap<Integer, double[]> gradeList;
	
	
	public ExerciseChecker(TreeMap<Integer, double[]> gradeList) {
		this.gradeList = gradeList ;
		this.teachingAssistantQueue = new Queue<Test>();
	}
	
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
