import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

public class InformationSystem {
	HashMap<Integer,Test> informationSystem;

	public InformationSystem() {
		informationSystem = new HashMap<Integer,Test>();
	}
	public boolean isEmpty(){
		return informationSystem.isEmpty();
		
	}
	public void add(Test nom) {
		informationSystem.put(nom.getId(), nom);
	}

	public Test find ( int id ) {
		return informationSystem.get(id);
		
			}
}