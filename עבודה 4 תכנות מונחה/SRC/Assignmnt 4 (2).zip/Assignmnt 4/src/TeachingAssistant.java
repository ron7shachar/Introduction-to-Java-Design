
public class TeachingAssistant implements Runnable {
	private Queue<Test> teachingAssistantQueue;
	private boolean[] answers ;
	private double p_error ;
	
	public TeachingAssistant(double p_error) {
		this.teachingAssistantQueue = new Queue<Test>();  
		answers = randomAnswers();
		this.p_error = p_error;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	private boolean[] randomAnswers() {
		// TODO Auto-generated method stub
		return null;
	}

}
