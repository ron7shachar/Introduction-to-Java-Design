
public class Proctor implements Runnable {

	private static Queue<Student> proctorQueue = new Queue<Student>(); ;
	
	public Proctor() {

	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
