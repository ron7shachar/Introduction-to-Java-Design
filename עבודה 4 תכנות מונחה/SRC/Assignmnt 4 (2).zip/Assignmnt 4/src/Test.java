
public class Test  {
	private int id ;
	private String date ;
	private boolean[] answers ;
	
	public double scoreWithoutFactor = 0.0;
	public double scoreAfterFactor= 0.0;
	public double finalScore= 0.0;

	public boolean signedByExaminer = false;
	public boolean tested1 = false;
	public boolean tested2 = false;
	public boolean approvedByTheCourseCoordinator = false;
	public boolean givenFactor = false;
	public boolean weighedWithWorks = false;
	public boolean EnteredIntoTheSystems = false;
	public boolean canned = false;
	public boolean ReadBTheStudent = false;
	 
	public Test (int id ,String date ,boolean[] answers ) {
		this.id = id ;
		this.date = date ;
		this.answers = answers ;
		
	}

	public int getId() {
		return id;
	}

	public String getDate() {
		return date;
	}

	public boolean[] getAnswers() {
		return answers;
	}

	

	
}
