

public class BoundedQueue<E> extends Queue<E> {
	int size;

	public BoundedQueue(int size) {
		super();
		this.size = size;
	}
	
	
	public boolean add (E nom) {
		if ( queue.size() < size-1) {
			queue.add(nom);
			return true;
		}
		return false;
		
	}
}
