
public class EDW implements Runnable {
	private static int totalNumberOfTests ;
	public  static BoundedQueue<Test> EDW_Queue = new BoundedQueue<Test>();
	public EDW(int totalNumberOfTests) {
		this.totalNumberOfTests = totalNumberOfTests;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
