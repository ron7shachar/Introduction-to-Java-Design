import java.util.Vector;

public class Queue<E> {
	protected Vector<E>  queue ;
	public Queue() {
	queue = new Vector<E>();
	
	}
	public boolean isEmpty(){
		return (queue.isEmpty());
	}
	public boolean add (E nom) {
		queue.add(nom);
		return true;
	}
	public E receive () {
		return queue.remove(0);
	}
}
