
public class Lecturer implements Runnable{
	public Queue<Test> lecturerQueue; 
	@Override
	public void run() {
		// TODO Auto-generated method stub
		lecturerQueue = new Queue<Test>();
	}
	public void finishingScans() {
		
	}

}
