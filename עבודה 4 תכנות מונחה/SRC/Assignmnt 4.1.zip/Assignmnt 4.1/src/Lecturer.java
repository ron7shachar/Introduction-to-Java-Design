import java.util.Vector;
///// ruth
public class Lecturer implements Runnable{
	
	private String name; 
	public Queue<Test> lecturerQueue;
	public Queue<Test> exerciseCheckerQueue;
	private Vector<Integer> BestStudents = new Vector<Integer>();
	private int nStudents = 0;
	private int totalGradesBeforeFactor = 0;
	private int totalGradesAfterFactor = 0;
	
	
	public Lecturer(String name, Queue<Test> lecturerQueue) {
		this.name = name;
		this.lecturerQueue = lecturerQueue;
	}
	
	@Override
	public void run() {
		while (true) { // TODO there are no more tests
			Test t;
		  	try {
		  		Thread.sleep(1000);
		  		
		  		t = lecturerQueue.extract();
		  		nStudents ++;
		  		totalGradesBeforeFactor += t.scoreWithoutFactor;
		  		
		  		int gradeAfterFactor = giveFactor(t);
		  		t.scoreAfterFactor = gradeAfterFactor;
		  		totalGradesAfterFactor += gradeAfterFactor;
		  		
		  		if (gradeAfterFactor > 95) {
		  			BestStudents.add(t.getId());
		  		}
		  		
		  		t.status = 4;
		  		exerciseCheckerQueue.insert(t);
		  		
		  	} catch (InterruptedException e) {}
		}	
		
	}
	
	private int giveFactor(Test t) {
		// TODO Auto-generated method stub
		return 0;
	}

	public void finishingScans() {
		// print all and total salary
		// send massage
	}

}
