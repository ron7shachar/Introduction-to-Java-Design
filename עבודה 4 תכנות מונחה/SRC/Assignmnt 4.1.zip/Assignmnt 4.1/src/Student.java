public class Student implements Runnable {

	private int id;
	private String name;
	private int classNumber;
	private double p;
	private int x;
	private int worksGrades[] =  new int[4];
	private Queue<Student> proctorsQueue;
	public BoundedQueue<Test> studentTest = new BoundedQueue<Test>(1);
	
	public Student (int id, String name ,int classNumber, double level, int rate, int[] worksGrades, Queue<Student> proctorsQueue) {
		this.id = id;
		this.name = name;
		this.classNumber = classNumber;
		this.p = level;
		this.x = rate;
		this.worksGrades = worksGrades;
		this.proctorsQueue = proctorsQueue;
	}
	
	@Override
	public void run() {
		/* run new test
		solve the test
		go to the procters queue
			run test
		wait to see the grade in information system
		if (he dont got a grade)
			return to wait
		change test status to "nitspa"
		*/
	}
	
	public int getClassNumber() {
		return classNumber;
	}

}
