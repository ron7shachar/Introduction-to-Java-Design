import java.util.TreeMap;

public class ExerciseChecker implements Runnable {

	private String name;
	private int salaryPerSecond = 1;
	private double totalSalary = 0;
	private Queue<Test> exerciseCheckerQueue;
	private TreeMap<Integer, double[]> gradeList;
	double assignmentsGrade ;
	
	public ExerciseChecker(TreeMap<Integer, double[]> gradeList, Queue<Test> exerciseCheckerQueue) {
		this.gradeList = gradeList ;
		this.exerciseCheckerQueue = exerciseCheckerQueue;
	}
	
	
	
	@Override
	public void run() {
		while (true) { // TODO there are no more tests
	while(exerciseCheckerQueue.isEmpty()) {
		try {
			exerciseCheckerQueue.wait();
		} catch (InterruptedException e) {}	

	}
	try {
		f(exerciseCheckerQueue.extract());
	} catch (InterruptedException e) {}
		}
	}


	private synchronized void f(Test test) {
		 double[] gradeList = this.gradeList.get(test.getId()); 
		 assignmentsGrade = 0.02*gradeList[0]+0.04*gradeList[1]+0.06*gradeList[2]+0.08*gradeList[3];
		 test.scoreAfterFactor = 0.8 * test.scoreWithoutFactor+0.2* assignmentsGrade ;
		 try {
			IEM_Secretary.iemSecretaryQueue.insert(test);
		} catch (InterruptedException e) {}
		 
		 IEM_Secretary.iemSecretaryQueue.notifyAll();
	}

}
