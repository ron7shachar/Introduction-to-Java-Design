import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;

public class InformationSystem {
	HashMap<Integer,Test> informationSystem;

	public InformationSystem() {
		informationSystem = new HashMap<Integer,Test>();
	}
	
	public synchronized boolean isEmpty(){
		return informationSystem.isEmpty();
	}
	
	public synchronized void add(Test nom) {
		informationSystem.put(nom.getId(), nom);
	}

	public synchronized Test find (int id) {
		return informationSystem.get(id);
	}
}