
public interface Profitable {

	public double profit();
}
